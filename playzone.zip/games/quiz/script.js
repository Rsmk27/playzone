
// Placeholder template. Implement game logic here.
document.getElementById('info').textContent = 'Coming soon…';
